<?php

/**
 * Dump the output of phpinfo()
 */

echo '<pre>';
phpinfo();
echo '</pre>';
echo '<!--EOF-->';
